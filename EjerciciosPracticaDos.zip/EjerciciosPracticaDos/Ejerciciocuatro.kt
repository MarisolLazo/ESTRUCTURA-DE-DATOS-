//Ejercicio 4: Crea un programa que permita al usuario ingresar 4 números enteros y los
//almacene en un array. Luego, encuentra y muestra el número mayor del array. Usa trycatch para manejar entradas no numéricas
fun main() {
    val numeros = Array(4) { 0 }

    for (i in numeros.indices) {
        while (true) {
            try {
                println("Ingresa un número entero (${i + 1}/4):")
                numeros[i] = readLine()?.toInt() ?: 0
                break
            } catch (e: NumberFormatException) {
                println("Entrada no válida. Por favor, ingresa un número entero.")
            }
        }
    }

    val numeroMayor = numeros.maxOrNull() ?: 0

    println("Números ingresados:")
    for (numero in numeros) {
        print("$numero ")
    }

    println("\nEl número mayor es: $numeroMayor")
}
