//Ejercicio 2: FizzBuzz
interface FizzBuzzLogic {
    fun executeFizzBuzz(n: Int)
}

class FizzBuzz : FizzBuzzLogic {
    override fun executeFizzBuzz(n: Int) {
        for (i in 1..n) {
            when {
                i % 3 == 0 && i % 5 == 0 -> print("FizzBuzz ")
                i % 3 == 0 -> print("Fizz ")
                i % 5 == 0 -> print("Buzz ")
                else -> print("$i ")
            }
            if (i % 10 == 0) println() 
        }
    }
}

fun main() {
    val fizzBuzz = FizzBuzz()
    fizzBuzz.executeFizzBuzz(100)
}
