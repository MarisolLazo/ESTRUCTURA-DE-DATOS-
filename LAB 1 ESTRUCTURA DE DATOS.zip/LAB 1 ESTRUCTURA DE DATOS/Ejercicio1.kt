//Ejercicio 1: Conteo de Números Primos, Pares e Impares
interface Numero {
    fun esPrimo(): Boolean
    fun esPar(): Boolean
    fun esImpar(): Boolean
}

class NumeroEntero(private val valor: Int) : Numero {

    override fun esPrimo(): Boolean {
        if (valor <= 1) return false
        for (i in 2..valor / 2) {
            if (valor % i == 0) return false
        }
        return true
    }

    override fun esPar(): Boolean {
        return valor % 2 == 0
    }

    override fun esImpar(): Boolean {
        return valor % 2 != 0
    }
}

fun main() {
    val n = 5 

    var primos = 0
    var pares = 0
    var impares = 0

    for (i in 1..n) {
        val numero = NumeroEntero(i)
        if (numero.esPrimo()) primos++
        if (numero.esPar()) pares++
        if (numero.esImpar()) impares++
    }

    println("Prime numbers count: $primos")
    println("Even numbers count: $pares")
    println("Odd numbers count: $impares")
}
