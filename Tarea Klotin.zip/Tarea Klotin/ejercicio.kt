// Interfaz común para todos los tipos de números
interface IBaseNumber {
    val value: Int
    fun printValue()
}

// Clase para representar números primos
class PrimeNumber(override val value: Int) : IBaseNumber {
    override fun printValue() {
        println("Número primo: $value")
    }
}

// Clase para representar números impares
class OddNumber(override val value: Int) : IBaseNumber {
    val divisores: List<Int> by lazy { obtenerDivisores(value) }

    override fun printValue() {
        println("Número impar: $value")
        println("Divisores: $divisores")
    }

    private fun obtenerDivisores(num: Int): List<Int> {
        return (1..num).filter { num % it == 0 }
    }
}

// Clase para representar números pares
class EvenNumber(override val value: Int) : IBaseNumber {
    val divisores: List<Int> by lazy { obtenerDivisores(value) }

    override fun printValue() {
        println("Número par: $value")
        println("Divisores: $divisores")
    }

    private fun obtenerDivisores(num: Int): List<Int> {
        return (1..num).filter { num % it == 0 }
    }
}

// Clase para procesar y clasificar números
class PrimeNumberProcessor(private val range: IntRange) {

    data class EvaluationResult(
        val primes: List<PrimeNumber>,
        val evens: List<EvenNumber>,
        val odds: List<OddNumber>
    )

    fun process(): EvaluationResult {
        val primes = mutableListOf<PrimeNumber>()
        val evens = mutableListOf<EvenNumber>()
        val odds = mutableListOf<OddNumber>()

        for (num in range) {
            when (validateNumber(num)) {
                NumberType.PRIME -> primes.add(PrimeNumber(num))
                NumberType.EVEN -> evens.add(EvenNumber(num))
                NumberType.ODD -> odds.add(OddNumber(num))
            }
        }

        return EvaluationResult(primes, evens, odds)
    }

    private fun validateNumber(num: Int): NumberType {
        return when {
            isPrime(num) -> NumberType.PRIME
            num % 2 == 0 -> NumberType.EVEN
            else -> NumberType.ODD
        }
    }

    private fun isPrime(num: Int): Boolean {
        if (num < 2) return false
        for (i in 2..Math.sqrt(num.toDouble()).toInt()) {
            if (num % i == 0) return false
        }
        return true
    }

    enum class NumberType {
        PRIME, EVEN, ODD
    }
}

fun main() {
    val range = 1..20
    val processor = PrimeNumberProcessor(range)
    val result = processor.process()

    // Imprimir números primos
    result.primes.forEach { it.printValue() }

    // Imprimir números pares y sus divisores
    result.evens.forEach { it.printValue() }

    // Imprimir números impares y sus divisores
    result.odds.forEach { it.printValue() }
}
